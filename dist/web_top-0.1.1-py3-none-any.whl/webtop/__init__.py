"""Webtop dummy module.

Nothing goes here, because at the moment all
code lives in `top-framework <https://github.com/tradingstrategy-ai/top-framework>`_ package.
"""